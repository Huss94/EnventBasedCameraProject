showLiveRetina('chip','tmpdiff128');
