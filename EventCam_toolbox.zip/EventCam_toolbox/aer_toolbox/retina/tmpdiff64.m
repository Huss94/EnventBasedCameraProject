showLiveRetina('chip','tmpdiff64');
