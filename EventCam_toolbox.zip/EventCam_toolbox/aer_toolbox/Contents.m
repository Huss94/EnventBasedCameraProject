%usbaemon.m -- the main matlab interface to grab AEs
%biasgen.m -- the main matlab interface to control an onchip biasgen
%testusbaemon.m tests usbaemon

