ae=ae_bin2mat('../../carre_aps.dat');
AE=eth2itn(ae,bitmask(11));
separation;
%AE.type(1:20)